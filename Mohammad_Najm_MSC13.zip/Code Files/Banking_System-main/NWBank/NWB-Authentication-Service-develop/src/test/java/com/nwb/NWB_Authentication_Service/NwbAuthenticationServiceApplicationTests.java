package com.nwb.NWB_Authentication_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NwbAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
