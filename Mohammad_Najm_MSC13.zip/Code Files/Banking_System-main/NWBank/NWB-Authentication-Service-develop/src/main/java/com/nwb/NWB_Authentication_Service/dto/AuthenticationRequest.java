package com.nwb.NWB_Authentication_Service.dto;

public record AuthenticationRequest(String username, String password) {
}
