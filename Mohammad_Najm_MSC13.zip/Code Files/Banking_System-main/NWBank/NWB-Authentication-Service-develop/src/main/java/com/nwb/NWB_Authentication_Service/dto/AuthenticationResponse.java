package com.nwb.NWB_Authentication_Service.dto;

public record AuthenticationResponse(String accesstoken) {
}
