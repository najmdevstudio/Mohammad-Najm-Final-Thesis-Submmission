package com.nwb.NWB_Authentication_Service.enums;

public enum Role {
    USER, ADMIN
}
