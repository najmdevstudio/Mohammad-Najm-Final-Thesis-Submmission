package com.nwb.NWB_Accounts.enums;

public enum AccountStatus {
    ACTIVE,
    INACTIVE,
    CLOSED,
    FROZEN
}
