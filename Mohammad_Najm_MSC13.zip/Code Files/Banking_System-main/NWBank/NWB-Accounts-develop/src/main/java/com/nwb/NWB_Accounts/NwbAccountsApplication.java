package com.nwb.NWB_Accounts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NwbAccountsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NwbAccountsApplication.class, args);
	}

}
