# NWB-Transaction-Service
_______

## New Age Bank
A Fictional Bank providing the most basic banking services online

## Transaction Service
Transaction service to provide incoming and outgoing transaction service