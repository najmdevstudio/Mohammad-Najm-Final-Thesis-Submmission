package com.nwb.NWB_Transaction_Service.enums;

public enum AccountStatus {
    ACTIVE,
    INACTIVE,
    CLOSED,
    FROZEN
}
