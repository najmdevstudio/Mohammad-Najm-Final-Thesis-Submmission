package com.nwb.NWB_Transaction_Service.dto;

public record TransactionResponse(String message, Integer transactionId) {
}
