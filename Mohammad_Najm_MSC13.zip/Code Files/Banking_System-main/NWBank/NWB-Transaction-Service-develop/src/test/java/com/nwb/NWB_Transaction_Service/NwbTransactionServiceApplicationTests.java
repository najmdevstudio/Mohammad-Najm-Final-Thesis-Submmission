package com.nwb.NWB_Transaction_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NwbTransactionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
