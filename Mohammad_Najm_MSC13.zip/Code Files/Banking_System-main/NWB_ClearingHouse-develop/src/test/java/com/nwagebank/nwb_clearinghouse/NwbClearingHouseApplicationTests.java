package com.nwagebank.nwb_clearinghouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NwbClearingHouseApplicationTests {

    @Test
    void contextLoads() {
    }

}
