package com.nwagebank.nwb_clearinghouse.services;

public interface BankRegistryService {
    String getBankTransactionServiceUrl(String ifscCode);
}
