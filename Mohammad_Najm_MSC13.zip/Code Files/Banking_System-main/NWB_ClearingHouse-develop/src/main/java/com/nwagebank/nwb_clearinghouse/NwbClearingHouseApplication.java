package com.nwagebank.nwb_clearinghouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NwbClearingHouseApplication {

    public static void main(String[] args) {
        SpringApplication.run(NwbClearingHouseApplication.class, args);
    }

}
