/******************************************************
 * transactions-script.js
 * A Node.js example showing:
 * 1) Authentication (Bearer token) per bank
 * 2) Submitting transactions with that token
 * 3) Measuring transaction times
 * 4) Finally, fetching transaction lists from each bank
 ******************************************************/

// 1) Dependencies
const axios = require('axios');
const { performance } = require('perf_hooks');

// 2) Transaction data (pasted from above)
// -----------------------------------------
const transactionsNWB = [
  // ... fill in your 15 NWB -> PW/OW transactions ...
  {
    fromAccount: 'AC1000002',
    toAccount:   'PWAC1000023',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'PWB0001',
    amount:      1024.50
  },
  {
    fromAccount: 'AC1000004',
    toAccount:   'OWAC1000012',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'OWB0001',
    amount:      854.10
  },
  {
    fromAccount: 'AC1000006',
    toAccount:   'OWAC1000047',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'OWB0001',
    amount:      2750.00
  },
  {
    fromAccount: 'AC1000009',
    toAccount:   'PWAC1000005',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'PWB0001',
    amount:      540.25
  },
  {
    fromAccount: 'AC1000011',
    toAccount:   'PWAC1000019',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'PWB0001',
    amount:      888.95
  },
  {
    fromAccount: 'AC1000019',
    toAccount:   'OWAC1000018',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'OWB0001',
    amount:      1122.49
  },
  {
    fromAccount: 'AC1000022',
    toAccount:   'OWAC1000031',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'OWB0001',
    amount:      300.00
  },
  {
    fromAccount: 'AC1000025',
    toAccount:   'PWAC1000029',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'PWB0001',
    amount:      2222.10
  },
  {
    fromAccount: 'AC1000027',
    toAccount:   'PWAC1000014',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'PWB0001',
    amount:      879.45
  },
  {
    fromAccount: 'AC1000032',
    toAccount:   'OWAC1000049',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'OWB0001',
    amount:      1005.77
  },
  {
    fromAccount: 'AC1000033',
    toAccount:   'PWAC1000041',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'PWB0001',
    amount:      333.33
  },
  {
    fromAccount: 'AC1000038',
    toAccount:   'OWAC1000016',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'OWB0001',
    amount:      234.67
  },
  {
    fromAccount: 'AC1000041',
    toAccount:   'OWAC1000009',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'OWB0001',
    amount:      578.00
  },
  {
    fromAccount: 'AC1000046',
    toAccount:   'PWAC1000048',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'PWB0001',
    amount:      2310.50
  },
  {
    fromAccount: 'AC1000049',
    toAccount:   'OWAC1000035',
    fromIFSCCode:    'NWB0001',
    toIFSCCode:      'OWB0001',
    amount:      3333.33
  }
];
const transactionsPW = [
  // ... fill in your 15 PW -> NWB/OW transactions ...
  {
    fromAccount: 'PWAC1000002',
    toAccount:   'AC1000020',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'NWB0001',
    amount:      1120.00
  },
  {
    fromAccount: 'PWAC1000005',
    toAccount:   'AC1000030',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'NWB0001',
    amount:      980.30
  },
  {
    fromAccount: 'PWAC1000007',
    toAccount:   'OWAC1000023',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'OWB0001',
    amount:      2250.49
  },
  {
    fromAccount: 'PWAC1000011',
    toAccount:   'OWAC1000039',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'OWB0001',
    amount:      114.25
  },
  {
    fromAccount: 'PWAC1000013',
    toAccount:   'AC1000001',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'NWB0001',
    amount:      3999.99
  },
  {
    fromAccount: 'PWAC1000016',
    toAccount:   'OWAC1000002',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'OWB0001',
    amount:      100.00
  },
  {
    fromAccount: 'PWAC1000019',
    toAccount:   'AC1000042',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'NWB0001',
    amount:      1249.76
  },
  {
    fromAccount: 'PWAC1000021',
    toAccount:   'OWAC1000028',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'OWB0001',
    amount:      945.00
  },
  {
    fromAccount: 'PWAC1000024',
    toAccount:   'AC1000034',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'NWB0001',
    amount:      2340.10
  },
  {
    fromAccount: 'PWAC1000028',
    toAccount:   'OWAC1000044',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'OWB0001',
    amount:      1675.90
  },
  {
    fromAccount: 'PWAC1000031',
    toAccount:   'AC1000049',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'NWB0001',
    amount:      751.22
  },
  {
    fromAccount: 'PWAC1000033',
    toAccount:   'OWAC1000005',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'OWB0001',
    amount:      569.44
  },
  {
    fromAccount: 'PWAC1000040',
    toAccount:   'AC1000022',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'NWB0001',
    amount:      422.70
  },
  {
    fromAccount: 'PWAC1000047',
    toAccount:   'OWAC1000017',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'OWB0001',
    amount:      847.55
  },
  {
    fromAccount: 'PWAC1000050',
    toAccount:   'AC1000003',
    fromIFSCCode:    'PWB0001',
    toIFSCCode:      'NWB0001',
    amount:      1500.00
  }
];
const transactionsOW = [
  // ... fill in your 15 OW -> NWB/PW transactions ...
  {
    fromAccount: 'OWAC1000003',
    toAccount:   'AC1000025',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'NWB0001',
    amount:      999.98
  },
  {
    fromAccount: 'OWAC1000005',
    toAccount:   'PWAC1000008',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'PWB0001',
    amount:      1000.00
  },
  {
    fromAccount: 'OWAC1000007',
    toAccount:   'PWAC1000015',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'PWB0001',
    amount:      2159.43
  },
  {
    fromAccount: 'OWAC1000009',
    toAccount:   'AC1000047',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'NWB0001',
    amount:      874.20
  },
  {
    fromAccount: 'OWAC1000012',
    toAccount:   'PWAC1000011',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'PWB0001',
    amount:      3333.12
  },
  {
    fromAccount: 'OWAC1000015',
    toAccount:   'AC1000010',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'NWB0001',
    amount:      277.77
  },
  {
    fromAccount: 'OWAC1000022',
    toAccount:   'AC1000028',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'NWB0001',
    amount:      125.00
  },
  {
    fromAccount: 'OWAC1000025',
    toAccount:   'PWAC1000003',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'PWB0001',
    amount:      102.30
  },
  {
    fromAccount: 'OWAC1000029',
    toAccount:   'AC1000040',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'NWB0001',
    amount:      2245.00
  },
  {
    fromAccount: 'OWAC1000034',
    toAccount:   'AC1000038',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'NWB0001',
    amount:      999.50
  },
  {
    fromAccount: 'OWAC1000037',
    toAccount:   'PWAC1000046',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'PWB0001',
    amount:      555.55
  },
  {
    fromAccount: 'OWAC1000042',
    toAccount:   'AC1000036',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'NWB0001',
    amount:      777.77
  },
  {
    fromAccount: 'OWAC1000045',
    toAccount:   'PWAC1000027',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'PWB0001',
    amount:      357.00
  },
  {
    fromAccount: 'OWAC1000048',
    toAccount:   'AC1000019',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'NWB0001',
    amount:      2000.00
  },
  {
    fromAccount: 'OWAC1000050',
    toAccount:   'PWAC1000038',
    fromIFSCCode:    'OWB0001',
    toIFSCCode:      'PWB0001',
    amount:      452.10
  }
];
const allTransactions = [...transactionsNWB, ...transactionsPW, ...transactionsOW];

// 3) Bank endpoints
// -----------------------------------------
// For demonstration, we assume each bank has a local endpoint.
// Adjust these to your actual server/port.
const NWB_API = 'http://localhost:8081'; // NWBank
const PW_API  = 'http://localhost:8089'; // PWBank
const OW_API  = 'http://localhost:8085'; // OWBank

// This function returns the correct base URL for a given IFSC code.
function getBankApiUrl(ifsc) {
  switch (ifsc) {
    case 'NWB0001': return NWB_API;
    case 'PWB0001':  return PW_API;
    case 'OWB0001':  return OW_API;
    default: throw new Error(`Unknown IFSC: ${ifsc}`);
  }
}

/******************************************************
 * 4) Authentication: Retrieve Bearer tokens
 *    We assume each bank uses:
 *    POST {baseUrl}/auth/login
 *    with body { "username":"admin", "password":"changeit" }
 ******************************************************/

// We'll store each bank's token in this object
// e.g. tokens['NWB0001'] = "Bearer abc..."
const tokens = {
  NWB0001: null,
  PWB0001:  null,
  OWB0001:  null
};

// Generic function to get a token from a bank
async function getAuthToken(baseUrl, username, password) {
  try {
    const resp = await axios.post(`${baseUrl}/auth/login`, {
      username,
      password
    });
    // Assume the response contains { token: '...' }
    // or { accessToken: '...' } — adapt as needed
    const token = resp.data.token || resp.data.accessToken || resp.data.accesstoken;
    if (!token) {
      throw new Error(`No token returned from ${baseUrl}/auth/login`);
    }
    return `Bearer ${token}`;
  } catch (err) {
    console.error(`Failed to get token from ${baseUrl}: ${err.message}`);
    throw err;
  }
}

// We'll get and store tokens for each bank by calling getAuthToken
async function authenticateBanks() {
  tokens['NWB0001'] = await getAuthToken(NWB_API, 'admin', 'changeit');
  tokens['PWB0001']  = await getAuthToken(PW_API,  'admin', 'changeit');
  tokens['OWB0001']  = await getAuthToken(OW_API,  'admin', 'changeit');

  console.log('--- AUTH TOKENS ---');
  console.log('NWB Token:', tokens['NWB0001']);
  console.log('PW Token:',  tokens['PWB0001']);
  console.log('OW Token:',  tokens['OWB0001']);
  console.log('-------------------\n');
}

/******************************************************
 * 5) Metrics tracking
 ******************************************************/
let totalTransactions = 0;
let totalTime = 0; // sum of request durations in ms
let transactionTimes = []; // store individual durations

/******************************************************
 * 6) Process all transactions
 ******************************************************/
async function processAllTransactions() {
  for (const tx of allTransactions) {
    try {
      const baseUrl = getBankApiUrl(tx.fromIFSCCode);

      // Decide which token to use
      const authToken = tokens[tx.fromIFSCCode]; 
      if (!authToken) {
        throw new Error(`No auth token for IFSC: ${tx.fromIFSCCode}`);
      }

      // Construct transaction payload
      const payload = {
        fromAccount: tx.fromAccount,
        toAccount: tx.toAccount,
        fromIFSCCode: tx.fromIFSCCode,
        toIFSCCode: tx.toIFSCCode,
        amount: tx.amount
      };

      // Start timer
      const start = performance.now();

      // POST request to /transactions
      const response = await axios.post(`${baseUrl}/transactions`, payload, {
        headers: {
          Authorization: authToken
        }
      });

      // End timer
      const end = performance.now();
      const duration = end - start;

      // Update metrics
      totalTransactions++;
      totalTime += duration;
      transactionTimes.push(duration);

      console.log(`Transaction from ${tx.fromAccount} to ${tx.toAccount} => SUCCESS`);
      console.log(`Status: ${response.status} | Time: ${duration.toFixed(2)} ms\n`);
    } catch (error) {
      console.error(`Transaction from ${tx.fromAccount} to ${tx.toAccount} => FAILED`);
      if (error.response) {
        console.error(` - Status: ${error.response.status}`);
        console.error(` - Data: ${JSON.stringify(error.response.data)}`);
      } else {
        console.error(` - Error: ${error.message}`);
      }
      console.error('');
    }
  }
}

/******************************************************
 * 7) Summarize metrics
 ******************************************************/
function summarizeMetrics() {
  console.log('--- TRANSACTION METRICS ---');
  if (totalTransactions === 0) {
    console.log('No transactions processed.');
    return;
  }

  const averageTime = totalTime / totalTransactions;
  console.log(`Total transactions:          ${totalTransactions}`);
  console.log(`Total transaction time (ms): ${totalTime.toFixed(2)}`);
  console.log(`Average transaction time (ms): ${averageTime.toFixed(2)}`);

  // fastest / slowest
  const maxTime = Math.max(...transactionTimes);
  const minTime = Math.min(...transactionTimes);
  console.log(`Fastest transaction (ms): ${minTime.toFixed(2)}`);
  console.log(`Slowest transaction (ms): ${maxTime.toFixed(2)}`);
  console.log('---------------------------\n');
}

/******************************************************
 * 8) Fetch all transactions from each bank
 *    using the same Bearer tokens
 ******************************************************/
async function fetchAllTransactions() {
  const banks = [
    { ifsc: 'NWB0001', url: NWB_API },
    { ifsc: 'PWB0001',  url: PW_API },
    { ifsc: 'OWB0001',  url: OW_API },
  ];

  for (const bank of banks) {
    console.log(`Fetching transactions from ${bank.ifsc}...`);
    try {
      const resp = await axios.get(`${bank.url}/transactions`, {
        headers: {
          Authorization: tokens[bank.ifsc]
        }
      });
      console.log(`Response from ${bank.ifsc}:`, resp.data, '\n');
    } catch (err) {
      console.error(`Failed to fetch transactions from ${bank.ifsc}: ${err.message}`);
    }
  }
}

/******************************************************
 * 9) Main Execution Flow
 ******************************************************/
(async function main() {
  try {
    console.log('Authenticating with each bank...\n');
    await authenticateBanks();

    console.log('Starting transaction processing...\n');
    await processAllTransactions();

    summarizeMetrics();

    console.log('Querying all transactions from each bank...\n');
    await fetchAllTransactions();

    console.log('Done!');
  } catch (err) {
    console.error('Script failed:', err.message);
  }
})();
