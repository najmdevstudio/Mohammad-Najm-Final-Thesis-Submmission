/******************************************************
 * transactions-script.js
 * 
 * A Node.js example showing:
 * 1) Authentication (Bearer token) per bank
 * 2) Submitting transactions with that token
 * 3) Capturing each created transaction's ID
 * 4) Querying each transaction by ID to avoid 500 errors
 *    on an unimplemented "get all" endpoint.
 * 
 * Assumes your "POST /transactions" returns something like:
 *   {
 *     "id": 1234,
 *     "fromAccount": "...",
 *     "toAccount": "...",
 *     ...
 *   }
 ******************************************************/

// 1) Dependencies
const axios = require('axios');
const { performance } = require('perf_hooks');

/******************************************************
 * 2) Transaction data
 ******************************************************/
const transactionsNWB = [
    {
      "fromAccount": "AC1000001",
      "toAccount": "PWAC1000001",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 8.00
    },
    {
      "fromAccount": "AC1000004",
      "toAccount": "PWAC1000006",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 220.00
    },
    {
      "fromAccount": "AC1000006",
      "toAccount": "PWAC1000024",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 100.00
    },
    {
      "fromAccount": "AC1000009",
      "toAccount": "OWAC1000004",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 100.00
    },
    {
      "fromAccount": "AC1000011",
      "toAccount": "OWAC1000037",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 500.00
    },
    {
      "fromAccount": "AC1000015",
      "toAccount": "OWAC1000039",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 130.00
    },
    {
      "fromAccount": "AC1000016",
      "toAccount": "PWAC1000039",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 30.00
    },
    {
      "fromAccount": "AC1000021",
      "toAccount": "OWAC1000009",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 30.00
    },
    {
      "fromAccount": "AC1000024",
      "toAccount": "PWAC1000009",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 30.00
    },
    {
      "fromAccount": "AC1000026",
      "toAccount": "OWAC1000035",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 100.00
    },
  
    {
      "fromAccount": "AC1000028",
      "toAccount": "PWAC1000035",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 40.00
    },
    {
      "fromAccount": "AC1000034",
      "toAccount": "OWAC1000048",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 70.00
    },
    {
      "fromAccount": "AC1000037",
      "toAccount": "PWAC1000046",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 90.00
    },
    {
      "fromAccount": "AC1000039",
      "toAccount": "OWAC1000046",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 800.00
    },
    {
      "fromAccount": "AC1000013",
      "toAccount": "PWAC1000048",
      "fromIFSCCode": "NWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 50.00
    }
  ];
  const transactionsPW = [
    {
      "fromAccount": "PWAC1000001",
      "toAccount": "AC1000024",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 90.00
    },
    {
      "fromAccount": "PWAC1000004",
      "toAccount": "OWAC1000028",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 20.00
    },
    {
      "fromAccount": "PWAC1000006",
      "toAccount": "AC1000004",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 100.00
    },
    {
      "fromAccount": "PWAC1000009",
      "toAccount": "OWAC1000034",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 15.00
    },
    {
      "fromAccount": "PWAC1000011",
      "toAccount": "AC1000034",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 25.00
    },
    {
      "fromAccount": "PWAC1000015",
      "toAccount": "OWAC1000037",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 10.00
    },
    {
      "fromAccount": "PWAC1000016",
      "toAccount": "AC1000026",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 30.00
    },
    {
      "fromAccount": "PWAC1000039",
      "toAccount": "AC1000015",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 100.00
    },
    {
      "fromAccount": "PWAC1000046",
      "toAccount": "OWAC1000001",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 80.00
    },
    {
      "fromAccount": "PWAC1000048",
      "toAccount": "OWAC1000009",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 200.00
    },
  
    {
      "fromAccount": "PWAC1000021",
      "toAccount": "AC1000006",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 55.00
    },
    {
      "fromAccount": "PWAC1000028",
      "toAccount": "OWAC1000045",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 20.00
    },
    {
      "fromAccount": "PWAC1000032",
      "toAccount": "AC1000032",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 700.00
    },
    {
      "fromAccount": "PWAC1000034",
      "toAccount": "OWAC1000026",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "OWB0001",
      "amount": 20.00
    },
    {
      "fromAccount": "PWAC1000050",
      "toAccount": "AC1000048",
      "fromIFSCCode": "PWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 50.00
    }
  ];
  const transactionsOW = [
    {
      "fromAccount": "OWAC1000001",
      "toAccount": "AC1000023",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 90.00
    },
    {
      "fromAccount": "OWAC1000004",
      "toAccount": "PWAC1000004",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 25.00
    },
    {
      "fromAccount": "OWAC1000006",
      "toAccount": "AC1000024",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 10.00
    },
    {
      "fromAccount": "OWAC1000009",
      "toAccount": "PWAC1000006",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 120.00
    },
    {
      "fromAccount": "OWAC1000011",
      "toAccount": "AC1000009",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 10.00
    },
    {
      "fromAccount": "OWAC1000015",
      "toAccount": "AC1000037",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 13.00
    },
    {
      "fromAccount": "OWAC1000016",
      "toAccount": "PWAC1000015",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 50.00
    },
    {
      "fromAccount": "OWAC1000037",
      "toAccount": "AC1000039",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 15.00
    },
    {
      "fromAccount": "OWAC1000039",
      "toAccount": "PWAC1000009",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 15.00
    },
    {
      "fromAccount": "OWAC1000046",
      "toAccount": "PWAC1000044",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 70.00
    },
  
    {
      "fromAccount": "OWAC1000003",
      "toAccount": "AC1000016",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 90.00
    },
    {
      "fromAccount": "OWAC1000021",
      "toAccount": "PWAC1000046",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 10.00
    },
    {
      "fromAccount": "OWAC1000023",
      "toAccount": "AC1000001",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 30.00
    },
    {
      "fromAccount": "OWAC1000032",
      "toAccount": "PWAC1000016",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "PWB0001",
      "amount": 20.00
    },
    {
      "fromAccount": "OWAC1000041",
      "toAccount": "AC1000045",
      "fromIFSCCode": "OWB0001",
      "toIFSCCode": "NWB0001",
      "amount": 18.60
    }
  ];

// Combine all transactions into one array
const allTransactions = [...transactionsNWB, ...transactionsPW, ...transactionsOW];

/******************************************************
 * 3) Bank endpoints
 ******************************************************/
// Adjust to your actual servers/ports
const NWB_API = 'http://localhost:8081'; // NWBank
const PW_API  = 'http://localhost:8089'; // PWBank
const OW_API  = 'http://localhost:8085'; // OWBank

// Return correct base URL for a given IFSC
function getBankApiUrl(ifsc) {
  switch (ifsc) {
    case 'NWB0001': return NWB_API;
    case 'PWB0001': return PW_API;
    case 'OWB0001': return OW_API;
    default: 
      throw new Error(`Unknown IFSC: ${ifsc}`);
  }
}

/******************************************************
 * 4) Authentication
 ******************************************************/
const tokens = {
  NWB0001: null,
  PWB0001: null,
  OWB0001: null
};

// Generic function to get an auth token
async function getAuthToken(baseUrl, username, password) {
  try {
    const resp = await axios.post(`${baseUrl}/auth/login`, { username, password });

    // Adjust to whatever your auth service returns
    const token = resp.data.token || resp.data.accessToken || resp.data.accesstoken;
    if (!token) {
      throw new Error(`No token returned from ${baseUrl}/auth/login`);
    }
    return `Bearer ${token}`;
  } catch (err) {
    console.error(`Failed to get token from ${baseUrl}: ${err.message}`);
    throw err;
  }
}

// Fetch tokens for each bank
async function authenticateBanks() {
  tokens['NWB0001'] = await getAuthToken(NWB_API, 'admin', 'changeit');
  tokens['PWB0001'] = await getAuthToken(PW_API,  'admin', 'changeit');
  tokens['OWB0001'] = await getAuthToken(OW_API,  'admin', 'changeit');

  console.log('--- AUTH TOKENS ---');
  console.log('NWB Token:', tokens['NWB0001']);
  console.log('PW Token:',  tokens['PWB0001']);
  console.log('OW Token:',  tokens['OWB0001']);
  console.log('-------------------\n');
}

/******************************************************
 * 5) Metrics Tracking
 ******************************************************/
let totalTransactions = 0;
let totalTime = 0; 
let transactionTimes = [];

/******************************************************
 * 6) Arrays to Store Created Transaction IDs
 *    We'll store each newly created transaction's ID,
 *    keyed by the IFSC that "created" it.
 ******************************************************/
const transactionIds = {
  NWB0001: [],
  PWB0001: [],
  OWB0001: []
};

/******************************************************
 * 7) Process (Create) All Transactions
 ******************************************************/
async function processAllTransactions() {
  for (const tx of allTransactions) {
    try {
      const baseUrl = getBankApiUrl(tx.fromIFSCCode);
      const authToken = tokens[tx.fromIFSCCode];

      if (!authToken) {
        throw new Error(`No auth token for IFSC: ${tx.fromIFSCCode}`);
      }

      const payload = {
        fromAccount:   tx.fromAccount,
        toAccount:     tx.toAccount,
        fromIFSCCode:  tx.fromIFSCCode,
        toIFSCCode:    tx.toIFSCCode,
        amount:        tx.amount
      };

      const start = performance.now();
      const response = await axios.post(`${baseUrl}/transactions`, payload, {
        headers: { Authorization: authToken }
      });

      const end = performance.now();
      const duration = end - start;

      totalTransactions++;
      totalTime += duration;
      transactionTimes.push(duration);

      console.log(`Transaction from ${tx.fromAccount} to ${tx.toAccount} => SUCCESS`);
      console.log(`Status: ${response.status} | Time: ${duration.toFixed(2)} ms\n`);

      // *** Store the newly created transaction ID ***
      if (response.data && response.data.id) {
        transactionIds[tx.fromIFSCCode].push(response.data.id);
      } else {
        console.warn(`Warning: No 'id' in response for transaction from ${tx.fromAccount}`);
      }

    } catch (error) {
      console.error(`Transaction from ${tx.fromAccount} to ${tx.toAccount} => FAILED`);
      if (error.response) {
        console.error(` - Status: ${error.response.status}`);
        console.error(` - Data: ${JSON.stringify(error.response.data)}`);
      } else {
        console.error(` - Error: ${error.message}`);
      }
      console.error('');
    }
  }
}

/******************************************************
 * 8) Summarize Transaction Metrics
 ******************************************************/
function summarizeMetrics() {
  console.log('--- TRANSACTION METRICS ---');
  if (totalTransactions === 0) {
    console.log('No transactions processed.');
    return;
  }

  const averageTime = totalTime / totalTransactions;
  console.log(`Total transactions:           ${totalTransactions}`);
  console.log(`Total transaction time (ms):  ${totalTime.toFixed(2)}`);
  console.log(`Average transaction time (ms): ${averageTime.toFixed(2)}`);

  const maxTime = Math.max(...transactionTimes);
  const minTime = Math.min(...transactionTimes);
  console.log(`Fastest transaction (ms):      ${minTime.toFixed(2)}`);
  console.log(`Slowest transaction (ms):      ${maxTime.toFixed(2)}`);
  console.log('---------------------------\n');
}

/******************************************************
 * Fetch all transactions from each bank by today's date
 * using the dateRange endpoint (startDate & endDate).
 * We ensure the date is in "YYYY-MM-DD" to match the
 * controller expecting @DateTimeFormat(iso = DateTimeFormat.ISO.DATE).
 ******************************************************/
async function fetchAllTransactions() {
    const banks = [
      { ifsc: 'NWB0001', url: NWB_API },
      { ifsc: 'PWB0001', url: PW_API },
      { ifsc: 'OWB0001', url: OW_API }
    ];
  
    // Base date in "YYYY-MM-DD"
    const dateStr = new Date().toLocaleDateString('en-CA');  // e.g., "2025-01-05"
  
    // Hard-code +05:30 offset
    const offset = '+05:30';
  
    // Build full datetime strings (e.g. "2025-01-05T00:00:00+05:30")
    const startDateTime = `${dateStr}T00:00:00${offset}`;
    const endDateTime   = `${dateStr}T23:59:59${offset}`;
  
    for (const bank of banks) {
      console.log(`\nFetching transactions from bank: ${bank.ifsc} for date=${dateStr} offset=${offset}`);
  
      const authToken = tokens[bank.ifsc];
      if (!authToken) {
        console.error(`No auth token for ${bank.ifsc}`);
        continue;
      }
  
      try {
        // GET /transactions/dateRange?startDate=YYYY-MM-DDTHH:mm:ss+05:30
        //                           &endDate=YYYY-MM-DDTHH:mm:ss+05:30
        const resp = await axios.get(`${bank.url}/transactions/dateRange`, {
          headers: { Authorization: authToken },
          params: {
            startDate: startDateTime,
            endDate: endDateTime
          }
        });
  
        console.log(
          `Transactions from ${startDateTime} to ${endDateTime} at bank=${bank.ifsc} =>`,
          resp.data
        );
      } catch (err) {
        console.error(`Failed to fetch transactions from ${bank.ifsc}: ${err.message}`);
      }
    }
  }
  
  

/******************************************************
 * 10) Main Execution Flow
 ******************************************************/
(async function main() {
  try {
    console.log('Authenticating with each bank...\n');
    await authenticateBanks();

    console.log('Starting transaction processing...\n');
    await processAllTransactions();

    summarizeMetrics();

    console.log('Querying all transactions (by ID) from each bank...\n');
    await fetchAllTransactions();

    console.log('\nDone!');
  } catch (err) {
    console.error('Script failed:', err.message);
  }
})();
